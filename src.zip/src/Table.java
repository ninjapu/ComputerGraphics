import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.List;

public class Table {
    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote--allow-origins=*");

        ChromeDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("http://seleniumpractise.blogspot.com/2021/08");

        //finding table by using xpath
        List<WebElement> allHeaders=driver.findElements(By.xpath("//table[contains(@id,'customer')]//th"));
        System.out.println(allHeaders.size());
        for (WebElement Web:allHeaders)
        {
            String Value=Web.getText();
            System.out.println(Value);

        }
    }

}