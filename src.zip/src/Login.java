import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Login {
    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("allow--origin=*");
        ChromeDriver driver = new ChromeDriver(options);
        driver.get("https://www.adactinhotelapp.com");

        driver.manage().window().maximize();

        String username = "jenil3797";
        String password = "abc@123";

        driver.findElement(By.name("username")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
        WebElement button = driver.findElement(By.id("login"));
        button.click();

        WebElement loginResult = driver.findElement(By.tagName("b"));
        String login = loginResult.getText();
        System.out.println(login);
        if (login.contains("Welcome")){
            System.out.println("Login successful! User: " + username + " is logged in.");
        }
        else{
            System.out.println("Login Failed! User: " + username );
        }
        driver.close();
    }
}
