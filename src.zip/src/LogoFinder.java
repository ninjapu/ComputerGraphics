import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LogoFinder {
    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote--allow-origins=*");

        ChromeDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();

        driver.get("https://www.google.com"); // Replace with the actual URL

        WebElement logoElement = driver.findElement(By.xpath("//img[@alt='Google']"));

        String logoUrl = logoElement.getAttribute("src");
        System.out.println("Logo URL: " + logoUrl);

        driver.get(logoUrl);
    }
}
