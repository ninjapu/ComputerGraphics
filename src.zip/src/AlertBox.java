import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class AlertBox {
    public static void main (String[] args)throws NoAlertPresentException, InterruptedException{
        ChromeOptions options = new ChromeOptions();
        options.addArguments("allow--origin=*");
        ChromeDriver driver = new ChromeDriver(options);
        driver.get("https://demo.guru99.com/test/delete_customer.php");

        driver.manage().window().maximize();

        driver.findElement(By.name("cusid")).sendKeys("12345");
        driver.findElement(By.name("submit")).submit();

        Alert alert = driver.switchTo().alert();

        String alertMessage = driver.switchTo().alert().getText();

        System.out.println(alertMessage);
        Thread.sleep(1000);

        alert.accept();
    }
}