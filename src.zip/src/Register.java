import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Register {
    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("allow--origin=*");
        ChromeDriver driver = new ChromeDriver(options);
        driver.get("https://www.adactinhotelapp.com/Register.php");

        driver.manage().window().maximize();

        String username = "jenil3797";
        String password = "abc@123";
        String fname = "Jenil Diyora";
        String email = "jenil@gmail.com";
        String captcha = "abler";

        driver.findElement(By.name("username")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
        driver.findElement(By.name("re_password")).sendKeys(password);
        driver.findElement(By.name("full_name")).sendKeys(fname);
        driver.findElement(By.name("email_add")).sendKeys(email);
        driver.findElement(By.name("captcha")).sendKeys(captcha);
        driver.findElement(By.name("tnc_box")).click();
        WebElement button = driver.findElement(By.id("Submit"));
        button.click();

        WebElement regResult = driver.findElement(By.tagName("reg_success"));
        if (regResult.isDisplayed()) {
            System.out.println("Login successful! User: " + username + " is Register Successfull.");
        } else {
            System.out.println("Login Failed! User: " + username );
        }
        driver.close();
    }
}