import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class DropdownOption {
    public static void main(String[] args) throws InterruptedException {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("allow--origin=*");

        ChromeDriver driver = new ChromeDriver(options);

        driver.get("https://trytestingthis.netlify.app/");

        driver.manage().window().maximize();

        WebElement select = driver.findElement(By.id("owc"));

        Select select1 = new Select(select);

        select1.selectByIndex(1);
        Thread.sleep(1000);

        select1.selectByValue("Options 2");
        Thread.sleep(1000);

        select1.selectByValue("Option 3");
        Thread.sleep(1000);

        select1.deselectByVisibleText("Option 3");

        Thread.sleep(1000);
        driver.close();
    }
}