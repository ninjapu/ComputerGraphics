import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class CheckBox {
    public static void main(String[] args) throws InterruptedException {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("allow--origin=*");

        ChromeDriver driver = new ChromeDriver(options);
        driver.get("https://trytestingthis.netlify.app/");
        driver.manage().window().maximize();


        WebElement Checkbox1 = driver.findElement(By.xpath("//input[@value='Option 1']"));
        boolean isSelected1 = Checkbox1.isSelected();
        if (isSelected1 == false) {
            Checkbox1.click();
        }

        WebElement Checkbox2 = driver.findElement(By.xpath("//input[@value='Option 2']"));
        boolean isSelected2 = Checkbox2.isSelected();
        if (isSelected2 == false) {
            Checkbox2.click();
        }

        WebElement Checkbox3 = driver.findElement(By.xpath("//input[@value='Option 3']"));
        boolean isSelected3 = Checkbox3.isSelected();
        if (isSelected3 == false) {
            Checkbox3.click();
        }
        Thread.sleep(1000);

    }
}