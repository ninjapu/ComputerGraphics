import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class RadioButton {
    public static void main(String[] args) throws InterruptedException{
        ChromeOptions options = new ChromeOptions();
        options.addArguments("allow--origin=*");

        ChromeDriver driver = new ChromeDriver(options);

        driver.get("https://trytestingthis.netlify.app/");

        driver.manage().window().maximize();

        WebElement RadioButton = driver.findElement(By.xpath("//label[normalize-space()='Female']"));

        RadioButton.click();
        Thread.sleep(1000);

        WebElement Raiobutton2 = driver.findElement(By.xpath("//label[normalize-space()='Male']"));

        Raiobutton2.click();
        Thread.sleep(1000);

        WebElement Raiobutton3 = driver.findElement(By.xpath("//label[normalize-space()='Other']"));
        Raiobutton3.click();

        Thread.sleep(1000);
        driver.quit();
    }
}