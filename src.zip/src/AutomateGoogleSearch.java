import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class AutomateGoogleSearch {
    public static void main(String[] args) throws InterruptedException {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote--allow-origins=*");

        ChromeDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("http:/www.google.com");

        WebElement username=driver.findElement(By.name("q"));
        username.sendKeys("Parul university");
        Thread.sleep(1000);

        driver.findElement(By.name("btnK")).click();
        Thread.sleep(1000);
    }
}